import { useTheme } from "../context/ThemeContext";

export const ThemeToggle = () => {
  const { darkMode, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
    >
      {darkMode ? "☀️" : "🌙"}
    </button>
  );
};
